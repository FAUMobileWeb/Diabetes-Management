/*Events and event handlers for site*/
$(function () {
    var site = {
        /*Hides the validation message, binds event handlers to events, and loads, if any, input information from localStorage*/
        init: function (){
            this.eventBind();
        },

        /*Binds event handlers to events*/
        eventBind: function() {
        }
    };

    /*Call to init*/
    site.init();
});
