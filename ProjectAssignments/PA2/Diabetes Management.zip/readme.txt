The credentials for this site are as follows:

username: jdoe123
password: pass123

The app has 6 fully functioning pages (login, home, weight tracking, dos and don'ts, profile, types of diabetes).