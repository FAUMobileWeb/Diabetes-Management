$(function () {
    var site = {
            this.eventBind();
        },

        eventBind: function() {
        }
    };

    /*Call to init*/
    site.init();
});
